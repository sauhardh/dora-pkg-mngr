use reqwest::Client;
use reqwest::Response;
use reqwest::multipart;
use reqwest::multipart::Part;

use std::path::Path;
use tokio::fs;

const URL: &str = "http://localhost:8000/publish";

pub async fn publish_artifacts(path: &Path) -> eyre::Result<Response> {
    let client = Client::builder()
        .timeout(std::time::Duration::from_secs(30))
        .build()?;

    let file_bytes = fs::read(&path).await?;

    let file_part = Part::bytes(file_bytes);
    let form = multipart::Form::new().part("file", file_part);

    let res = client.post(URL).multipart(form).send().await?;

    if !res.status().is_success() {
        let status = res.status();

        let body = res
            .text()
            .await
            .unwrap_or_else(|_| "<Failed to read body>".to_string());

        return Err(eyre::eyre!(
            "Failed to publish: {}.\n   Reason: {:?}",
            status,
            body
        ));
    }

    Ok(res)
}

#[tokio::test]
async fn test_publish_artifacts() {
    let path = Path::new(
        "/home/sk/Desktop/contribute/working/dora/libraries/dora-package-manager/nodename-0.0.1.tar.gz",
    );
    let result = publish_artifacts(&path).await;

    println!("Res {:#?}", result);
}
